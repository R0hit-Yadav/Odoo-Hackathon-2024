EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'pnp7372@gmail.com'
EMAIL_HOST_PASSWORD = 'thre uedv buqe qtfe'
EMAIL_PORT  = 587