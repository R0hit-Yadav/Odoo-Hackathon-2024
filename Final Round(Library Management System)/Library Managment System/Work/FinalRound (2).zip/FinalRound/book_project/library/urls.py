from django.urls import path
from . import views

urlpatterns = [
    path('search/', views.search_books, name='search_books'),
    path('add_to_store/', views.add_to_store, name='add_to_store'),
    path('crud_operations/', views.crud_operations, name='crud_operations'),
    path('delete_book/', views.delete_book, name='delete_book'),
    path('view_all_books/', views.view_all_books, name='view_all_books'),
    path('update_book/', views.update_book, name='update_book'),

]



