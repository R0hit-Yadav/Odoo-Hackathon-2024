# myproject/urls.py

from django.contrib import admin
from django.urls import path
from payments.views import PaymentView, payment_success, payment_failure

urlpatterns = [
    path('admin/', admin.site.urls),
    path('payment/', PaymentView.as_view(), name='payment'),
    path('payment-success/', payment_success, name='payment_success'),
    path('payment-failure/', payment_failure, name='payment_failure'),
]
