# payments/models.py

from django.db import models

class Payment(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)
    paypal_payment_id = models.CharField(max_length=50)
    success = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.amount} - {self.success}"
