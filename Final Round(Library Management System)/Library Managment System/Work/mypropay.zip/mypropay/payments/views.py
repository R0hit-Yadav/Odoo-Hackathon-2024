# payments/views.py

from django.conf import settings
from django.shortcuts import render, redirect
from django.views import View
import paypalrestsdk
from .models import Payment

paypalrestsdk.configure({
    "mode": settings.PAYPAL_MODE,
    "client_id": settings.PAYPAL_CLIENT_ID,
    "client_secret": settings.PAYPAL_CLIENT_SECRET
})

class PaymentView(View):
    def get(self, request):
        return render(request, 'payments/payment.html')

    def post(self, request):
        amount = request.POST.get('amount')
        payment = paypalrestsdk.Payment({
            "intent": "sale",
            "payer": {
                "payment_method": "paypal"
            },
            "transactions": [{
                "amount": {
                    "total": amount,
                    "currency": "USD"
                },
                "description": "Payment description"
            }],
            "redirect_urls": {
                "return_url": request.build_absolute_uri('/payment-success/'),
                "cancel_url": request.build_absolute_uri('/payment-failure/')
            }
        })

        if payment.create():
            for link in payment.links:
                if link.rel == "approval_url":
                    approval_url = link.href
                    payment_id = payment.id
                    Payment.objects.create(amount=amount, paypal_payment_id=payment_id, success=False)
                    return redirect(approval_url)
        else:
            return redirect('payment_failure')

def payment_success(request):
    payment_id = request.GET.get('paymentId')
    payer_id = request.GET.get('PayerID')
    payment = paypalrestsdk.Payment.find(payment_id)

    if payment.execute({"payer_id": payer_id}):
        payment_record = Payment.objects.get(paypal_payment_id=payment_id)
        payment_record.success = True
        payment_record.save()
        return render(request, 'payments/payment_success.html', payment_record)
    else:
        return redirect('payment_failure')

def payment_failure(request):
    return render(request, 'payments/payment_failure.html')
